# Global CO₂ Emissions and Energy Consumption EDA Project

## Objective
Explore how global CO₂ emissions and energy consumption patterns have evolved from 1990 to 2023, identifying major contributing countries, industries, and correlations.

## Tools Used
- Python
- Pandas, NumPy
- Matplotlib, Seaborn, Plotly
- Jupyter Notebook

## Dataset Sources
- Our World in Data – CO₂ Emissions: https://ourworldindata.org/co2-emissions
- World Bank – Energy Use: https://data.worldbank.org/indicator/EG.USE.PCAP.KG.OE

## Files Included
- `eda_co2_analysis.ipynb`: Main analysis notebook
- `README.md`: Project overview and setup instructions

## Instructions
1. Download the dataset CSV files into the project folder.
2. Run the Jupyter Notebook step-by-step.
3. Explore visualizations and insights generated from the analysis.
